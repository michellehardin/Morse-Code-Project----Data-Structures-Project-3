#pragma once
using namespace std; 

//Given in project 3's guidelines
char MorseTree[63] =
{
	//first row
	'\0',
	//second row
	'E', 'T',
	//third row
	'I', 'A', 'N', 'M',
	//4th row
	'S', 'U','R','W','D','K','G','O',
	//5th row
	'H', 'V','F','\0','L','\0','P','J',
	'B', 'X','C','Y','Z','Q','\0','\0',
	//6th ro
	'5', '4','\0','3','\0','\0','\0','2','\0','\0','+','\0','\0','\0','\0','1',
	'6', '=','/','\0','\0','\0','\0','\0','7','\0','\0','\0','8','\0','9','0'
}; 

